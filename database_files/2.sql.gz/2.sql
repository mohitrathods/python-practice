-- SELECT *
--   FROM information_schema.columns
--  WHERE table_schema = 'sales'
--    AND table_name   = 'staffs'


-- select * from production.stocks
-- select * from 
-- ((production.products p
-- LEFT JOIN production.categories c
-- On p.category_id = c.category_id
-- where p.brand_id = p.category_id

-- SELECT product.product_name, stock.quantity
-- FROM production.products product
-- INNER JOIN production.stocks stock
-- On product.product_id = stock.product_id
-- -- GROUP BY (product.product_name)
-- order by stock.quantity






select * FROM sale_order_line



