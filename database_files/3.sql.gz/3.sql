-- INSERT INTO sale_order(order_name, customer_id, order_status) VALUES('a',1,'b');
-- select * from sale_order
-- select STRING_AGG(product_id::character varying ,', ') from production.products
-- select * from sale_order_line
-- select count(id),order_id from sale_order_line group by(order_id)
-- where order_id = 161

-- select * from sale_order

-- SELECT id, order_status,
-- CASE
-- 	WHEN id > 10 THEN 'greater than 10'
-- 	WHEN id < 10 THEN 'less than 10'
-- 	ELSE 'in else'
-- 	END
-- FROM sale_order